﻿
namespace Kalkulator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.n1 = new System.Windows.Forms.Button();
            this.n2 = new System.Windows.Forms.Button();
            this.n3 = new System.Windows.Forms.Button();
            this.bad = new System.Windows.Forms.Button();
            this.bsub = new System.Windows.Forms.Button();
            this.n6 = new System.Windows.Forms.Button();
            this.n5 = new System.Windows.Forms.Button();
            this.n4 = new System.Windows.Forms.Button();
            this.bmult = new System.Windows.Forms.Button();
            this.n9 = new System.Windows.Forms.Button();
            this.n8 = new System.Windows.Forms.Button();
            this.n7 = new System.Windows.Forms.Button();
            this.bdiv = new System.Windows.Forms.Button();
            this.bc = new System.Windows.Forms.Button();
            this.b0 = new System.Windows.Forms.Button();
            this.bdot = new System.Windows.Forms.Button();
            this.bequal = new System.Windows.Forms.Button();
            this.broot = new System.Windows.Forms.Button();
            this.brank = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox1.Location = new System.Drawing.Point(12, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(286, 49);
            this.textBox1.TabIndex = 0;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // n1
            // 
            this.n1.BackColor = System.Drawing.SystemColors.Highlight;
            this.n1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.n1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.n1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.n1.Location = new System.Drawing.Point(12, 80);
            this.n1.Name = "n1";
            this.n1.Size = new System.Drawing.Size(55, 55);
            this.n1.TabIndex = 1;
            this.n1.Text = "1";
            this.n1.UseVisualStyleBackColor = false;
            this.n1.Click += new System.EventHandler(this.n1_Click);
            // 
            // n2
            // 
            this.n2.BackColor = System.Drawing.SystemColors.Highlight;
            this.n2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.n2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.n2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.n2.Location = new System.Drawing.Point(85, 80);
            this.n2.Name = "n2";
            this.n2.Size = new System.Drawing.Size(55, 55);
            this.n2.TabIndex = 2;
            this.n2.Text = "2";
            this.n2.UseVisualStyleBackColor = false;
            this.n2.Click += new System.EventHandler(this.n2_Click);
            // 
            // n3
            // 
            this.n3.BackColor = System.Drawing.SystemColors.Highlight;
            this.n3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.n3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.n3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.n3.Location = new System.Drawing.Point(163, 80);
            this.n3.Name = "n3";
            this.n3.Size = new System.Drawing.Size(55, 55);
            this.n3.TabIndex = 3;
            this.n3.Text = "3";
            this.n3.UseVisualStyleBackColor = false;
            this.n3.Click += new System.EventHandler(this.n3_Click);
            // 
            // bad
            // 
            this.bad.BackColor = System.Drawing.SystemColors.Highlight;
            this.bad.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bad.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bad.Location = new System.Drawing.Point(243, 80);
            this.bad.Name = "bad";
            this.bad.Size = new System.Drawing.Size(55, 55);
            this.bad.TabIndex = 4;
            this.bad.Text = "+";
            this.bad.UseVisualStyleBackColor = false;
            this.bad.Click += new System.EventHandler(this.bad_Click);
            // 
            // bsub
            // 
            this.bsub.BackColor = System.Drawing.SystemColors.Highlight;
            this.bsub.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bsub.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bsub.Location = new System.Drawing.Point(243, 160);
            this.bsub.Name = "bsub";
            this.bsub.Size = new System.Drawing.Size(55, 55);
            this.bsub.TabIndex = 8;
            this.bsub.Text = "-";
            this.bsub.UseVisualStyleBackColor = false;
            this.bsub.Click += new System.EventHandler(this.bsub_Click);
            // 
            // n6
            // 
            this.n6.BackColor = System.Drawing.SystemColors.Highlight;
            this.n6.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.n6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.n6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.n6.Location = new System.Drawing.Point(163, 160);
            this.n6.Name = "n6";
            this.n6.Size = new System.Drawing.Size(55, 55);
            this.n6.TabIndex = 7;
            this.n6.Text = "6";
            this.n6.UseVisualStyleBackColor = false;
            this.n6.Click += new System.EventHandler(this.n6_Click);
            // 
            // n5
            // 
            this.n5.BackColor = System.Drawing.SystemColors.Highlight;
            this.n5.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.n5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.n5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.n5.Location = new System.Drawing.Point(85, 160);
            this.n5.Name = "n5";
            this.n5.Size = new System.Drawing.Size(55, 55);
            this.n5.TabIndex = 6;
            this.n5.Text = "5";
            this.n5.UseVisualStyleBackColor = false;
            this.n5.Click += new System.EventHandler(this.n5_Click);
            // 
            // n4
            // 
            this.n4.BackColor = System.Drawing.SystemColors.Highlight;
            this.n4.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.n4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.n4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.n4.Location = new System.Drawing.Point(12, 160);
            this.n4.Name = "n4";
            this.n4.Size = new System.Drawing.Size(55, 55);
            this.n4.TabIndex = 5;
            this.n4.Text = "4";
            this.n4.UseVisualStyleBackColor = false;
            this.n4.Click += new System.EventHandler(this.n4_Click);
            // 
            // bmult
            // 
            this.bmult.BackColor = System.Drawing.SystemColors.Highlight;
            this.bmult.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bmult.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bmult.Location = new System.Drawing.Point(243, 240);
            this.bmult.Name = "bmult";
            this.bmult.Size = new System.Drawing.Size(55, 55);
            this.bmult.TabIndex = 12;
            this.bmult.Text = "*";
            this.bmult.UseVisualStyleBackColor = false;
            this.bmult.Click += new System.EventHandler(this.bmult_Click);
            // 
            // n9
            // 
            this.n9.BackColor = System.Drawing.SystemColors.Highlight;
            this.n9.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.n9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.n9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.n9.Location = new System.Drawing.Point(163, 240);
            this.n9.Name = "n9";
            this.n9.Size = new System.Drawing.Size(55, 55);
            this.n9.TabIndex = 11;
            this.n9.Text = "9";
            this.n9.UseVisualStyleBackColor = false;
            this.n9.Click += new System.EventHandler(this.n9_Click);
            // 
            // n8
            // 
            this.n8.BackColor = System.Drawing.SystemColors.Highlight;
            this.n8.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.n8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.n8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.n8.Location = new System.Drawing.Point(85, 240);
            this.n8.Name = "n8";
            this.n8.Size = new System.Drawing.Size(55, 55);
            this.n8.TabIndex = 10;
            this.n8.Text = "8";
            this.n8.UseVisualStyleBackColor = false;
            this.n8.Click += new System.EventHandler(this.n8_Click);
            // 
            // n7
            // 
            this.n7.BackColor = System.Drawing.SystemColors.Highlight;
            this.n7.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.n7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.n7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.n7.Location = new System.Drawing.Point(12, 240);
            this.n7.Name = "n7";
            this.n7.Size = new System.Drawing.Size(55, 55);
            this.n7.TabIndex = 9;
            this.n7.Text = "7";
            this.n7.UseVisualStyleBackColor = false;
            this.n7.Click += new System.EventHandler(this.n7_Click);
            // 
            // bdiv
            // 
            this.bdiv.BackColor = System.Drawing.SystemColors.Highlight;
            this.bdiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bdiv.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bdiv.Location = new System.Drawing.Point(243, 321);
            this.bdiv.Name = "bdiv";
            this.bdiv.Size = new System.Drawing.Size(55, 55);
            this.bdiv.TabIndex = 16;
            this.bdiv.Text = "/";
            this.bdiv.UseVisualStyleBackColor = false;
            this.bdiv.Click += new System.EventHandler(this.bdiv_Click);
            // 
            // bc
            // 
            this.bc.BackColor = System.Drawing.Color.Crimson;
            this.bc.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bc.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bc.Location = new System.Drawing.Point(163, 321);
            this.bc.Name = "bc";
            this.bc.Size = new System.Drawing.Size(55, 55);
            this.bc.TabIndex = 15;
            this.bc.Text = "C";
            this.bc.UseVisualStyleBackColor = false;
            this.bc.Click += new System.EventHandler(this.bc_Click);
            // 
            // b0
            // 
            this.b0.BackColor = System.Drawing.SystemColors.Highlight;
            this.b0.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.b0.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.b0.ForeColor = System.Drawing.SystemColors.ControlText;
            this.b0.Location = new System.Drawing.Point(85, 321);
            this.b0.Name = "b0";
            this.b0.Size = new System.Drawing.Size(55, 55);
            this.b0.TabIndex = 14;
            this.b0.Text = "0";
            this.b0.UseVisualStyleBackColor = false;
            this.b0.Click += new System.EventHandler(this.b0_Click);
            // 
            // bdot
            // 
            this.bdot.BackColor = System.Drawing.SystemColors.Highlight;
            this.bdot.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.bdot.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bdot.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bdot.Location = new System.Drawing.Point(12, 321);
            this.bdot.Name = "bdot";
            this.bdot.Size = new System.Drawing.Size(55, 55);
            this.bdot.TabIndex = 13;
            this.bdot.Text = ".";
            this.bdot.UseVisualStyleBackColor = false;
            this.bdot.Click += new System.EventHandler(this.bdot_Click);
            // 
            // bequal
            // 
            this.bequal.BackColor = System.Drawing.SystemColors.Highlight;
            this.bequal.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bequal.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bequal.Location = new System.Drawing.Point(163, 402);
            this.bequal.Name = "bequal";
            this.bequal.Size = new System.Drawing.Size(55, 55);
            this.bequal.TabIndex = 19;
            this.bequal.Text = "=";
            this.bequal.UseVisualStyleBackColor = false;
            this.bequal.Click += new System.EventHandler(this.bequal_Click);
            // 
            // broot
            // 
            this.broot.BackColor = System.Drawing.SystemColors.Highlight;
            this.broot.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.broot.ForeColor = System.Drawing.SystemColors.ControlText;
            this.broot.Location = new System.Drawing.Point(85, 402);
            this.broot.Name = "broot";
            this.broot.Size = new System.Drawing.Size(55, 55);
            this.broot.TabIndex = 18;
            this.broot.Text = "√";
            this.broot.UseVisualStyleBackColor = false;
            this.broot.Click += new System.EventHandler(this.broot_Click);
            // 
            // brank
            // 
            this.brank.BackColor = System.Drawing.SystemColors.Highlight;
            this.brank.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.brank.ForeColor = System.Drawing.SystemColors.ControlText;
            this.brank.Location = new System.Drawing.Point(12, 402);
            this.brank.Name = "brank";
            this.brank.Size = new System.Drawing.Size(55, 55);
            this.brank.TabIndex = 17;
            this.brank.Text = "^";
            this.brank.UseVisualStyleBackColor = false;
            this.brank.Click += new System.EventHandler(this.brank_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(310, 481);
            this.Controls.Add(this.bequal);
            this.Controls.Add(this.broot);
            this.Controls.Add(this.brank);
            this.Controls.Add(this.bdiv);
            this.Controls.Add(this.bc);
            this.Controls.Add(this.b0);
            this.Controls.Add(this.bdot);
            this.Controls.Add(this.bmult);
            this.Controls.Add(this.n9);
            this.Controls.Add(this.n8);
            this.Controls.Add(this.n7);
            this.Controls.Add(this.bsub);
            this.Controls.Add(this.n6);
            this.Controls.Add(this.n5);
            this.Controls.Add(this.n4);
            this.Controls.Add(this.bad);
            this.Controls.Add(this.n3);
            this.Controls.Add(this.n2);
            this.Controls.Add(this.n1);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Kalkulator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button n1;
        private System.Windows.Forms.Button n2;
        private System.Windows.Forms.Button n3;
        private System.Windows.Forms.Button bad;
        private System.Windows.Forms.Button bsub;
        private System.Windows.Forms.Button n6;
        private System.Windows.Forms.Button n5;
        private System.Windows.Forms.Button n4;
        private System.Windows.Forms.Button bmult;
        private System.Windows.Forms.Button n9;
        private System.Windows.Forms.Button n8;
        private System.Windows.Forms.Button n7;
        private System.Windows.Forms.Button bdiv;
        private System.Windows.Forms.Button bc;
        private System.Windows.Forms.Button b0;
        private System.Windows.Forms.Button bdot;
        private System.Windows.Forms.Button bequal;
        private System.Windows.Forms.Button broot;
        private System.Windows.Forms.Button brank;
    }
}

